
const dummyData = {
  "2024": {
    "dhaka": {
      "101": {
        "name": "Antor Rahman",
        "result": "GPA 5.00"
      },
      "102": {
        "name": "Rafiul Hasan",
        "result": "GPA 4.20"
      }
    },
    "rajshahi": {
      "101": {
        "name": "Shakib Ali",
        "result": "GPA 4.50"
      }
    }
  }
};

function checkResult() {
  const roll = document.getElementById("roll").value.trim();
  const reg = document.getElementById("reg").value.trim();
  const board = document.getElementById("board").value;
  const year = document.getElementById("year").value.trim();
  const resultBox = document.getElementById("result");

  if (!roll || !reg || !year) {
    resultBox.innerHTML = "<p>Please enter all details.</p>";
    return;
  }

  const yearData = dummyData[year];
  if (!yearData) {
    resultBox.innerHTML = "<p>No data found for the year " + year + "</p>";
    return;
  }

  const boardData = yearData[board];
  if (!boardData) {
    resultBox.innerHTML = "<p>No data found for the board " + board + "</p>";
    return;
  }

  const student = boardData[roll];
  if (student) {
    resultBox.innerHTML = `<p>Name: ${student.name}</p><p>Result: ${student.result}</p>`;
  } else {
    resultBox.innerHTML = "<p>No result found for this roll number.</p>";
  }
}
    